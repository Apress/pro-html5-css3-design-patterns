$.templateLayoutShowOnReady();

$(document).ready(function() { 

	$.setTemplateLayout();

});